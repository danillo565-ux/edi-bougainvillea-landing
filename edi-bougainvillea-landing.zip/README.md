# Edi Bougainvillea - Landing Page

Landing page do aplicativo Edi Bougainvillea - O primeiro app inteligente 100% para Bougainvilleas.

## 🚀 Link da página
https://SEU-USUARIO.github.io/edi-bougainvillea-landing

## 📱 Sobre o app
- Diagnóstico por foto e áudio
- Chat com IA especializada
- Comunidade de cultivadores
- Clube com níveis e conquistas

---
**Desenvolvido por Edi Bougainvillea**
